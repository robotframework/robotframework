class ZipLib:

    def kw_from_zip(self, arg):
        print(arg)
        return arg * 2
