class ZipLib:

	def kw_from_zip(self, arg):
		print '*INFO*', arg
		return arg * 2


